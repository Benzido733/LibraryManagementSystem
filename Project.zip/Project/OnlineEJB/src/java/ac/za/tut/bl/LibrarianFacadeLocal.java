/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ac.za.tut.bl;

import ac.za.tut.entities.Librarian;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author light
 */
@Local
public interface LibrarianFacadeLocal {

    void create(Librarian librarian);

    void edit(Librarian librarian);

    void remove(Librarian librarian);

    Librarian find(Object id);

    List<Librarian> findAll();

    List<Librarian> findRange(int[] range);

    int count();
    
   Librarian findLibrarian(String name , long id);
   
    
}
