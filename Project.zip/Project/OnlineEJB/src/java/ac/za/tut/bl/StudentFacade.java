/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.za.tut.bl;

import ac.za.tut.entities.Student;
import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author light
 */
@Stateless
public class StudentFacade extends AbstractFacade<Student> implements StudentFacadeLocal {

    @PersistenceContext(unitName = "OnlineEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentFacade() {
        super(Student.class);
    }

 @Override
public Student findStudent(String name, Long id) {
    Query query = em.createQuery("SELECT s FROM Student s WHERE s.id = :targetid AND s.firstName = :targetName");
    query.setParameter("targetid", id);
    query.setParameter("targetName", name);
    List<Student> results = query.getResultList();
    return results.isEmpty() ? null : results.get(0);
}


   
    
}
