/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ac.za.tut.bl;

import ac.za.tut.entities.BorrowRecord;
import ac.za.tut.entities.Student;
import java.util.List;
import javax.ejb.Local;

/**
 *
 * @author light
 */
@Local
public interface BorrowRecordFacadeLocal {

    void create(BorrowRecord borrowRecord);

    void edit(BorrowRecord borrowRecord);

    void remove(BorrowRecord borrowRecord);

    BorrowRecord find(Object id);

    List<BorrowRecord> findAll();

    List<BorrowRecord> findRange(int[] range);

    int count();
    
    String borrowBook(Long studentid , Long bookID);
    
    String returnBook(Long studentid , Long bookID);

    public List<BorrowRecord> findByStudent(Student student);

   public List<BorrowRecord> getBorrowRecordsByStudent(Long studentId);

    
    List<BorrowRecord> getUnreturnedRecordsByStudent(Long studentId);

}
