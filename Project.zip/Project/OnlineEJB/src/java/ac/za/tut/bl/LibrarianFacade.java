/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.za.tut.bl;

import ac.za.tut.entities.Librarian;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author light
 */
@Stateless
public class LibrarianFacade extends AbstractFacade<Librarian> implements LibrarianFacadeLocal {

    @PersistenceContext(unitName = "OnlineEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public LibrarianFacade() {
        super(Librarian.class);
    }

   @Override
public Librarian findLibrarian(String name, long id) {
   Librarian l =new Librarian();
    return l;
}


 
    
}
