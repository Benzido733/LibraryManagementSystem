/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ac.za.tut.bl;

import ac.za.tut.entities.Book;
import ac.za.tut.entities.BorrowRecord;
import ac.za.tut.entities.Student;
import java.util.Date;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author light
 */
@Stateless
public class BorrowRecordFacade extends AbstractFacade<BorrowRecord> implements BorrowRecordFacadeLocal {

    @PersistenceContext(unitName = "OnlineEJBPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public BorrowRecordFacade() {
        super(BorrowRecord.class);
    }

    @Override
    public String borrowBook(Long studentid, Long bookID) {
        Student student = em.find(Student.class, studentid);
        Book book = em.find(Book.class, bookID);
        
        if(book.getQuantity() <= 0) return "Book mot available";
        
        BorrowRecord record = new BorrowRecord();
        record.setBook(book);
        record.setStudent(student);
        record.setBorrowDate(new Date());
        record.setReturned(false);
        
        em.getTransaction().begin();
        book.setQuantity(book.getQuantity()-1);
        em.persist(record);
        em.merge(book);
        em.getTransaction().commit();
        
        return "Book borrowed succeffully";

    }

 @Override
public String returnBook(Long studentid, Long bookID) {
    TypedQuery<BorrowRecord> query = em.createQuery(
        "SELECT br FROM BorrowRecord br WHERE br.student.id = :sid AND br.book.id = :bid AND br.returned = false", 
        BorrowRecord.class);
    
    query.setParameter("sid", studentid);
    query.setParameter("bid", bookID); // Corrected parameter name for book ID

    BorrowRecord record;
    
    try {
        // Fetch the BorrowRecord from the query result
        record = query.getSingleResult();
    } catch (Exception e) {
        // Handle case where no such borrow record is found
        return "No active borrow record found for the student and book.";
    }
    
    // Start the transaction to return the book
    em.getTransaction().begin();
    record.setReturnDate(new Date());  // Set return date
    record.setReturned(true);  // Mark the book as returned
    
    // Update the book quantity
    Book book = record.getBook();
    book.setQuantity(book.getQuantity() + 1);  // Increment book quantity
    
    em.merge(record);  // Update borrow record
    em.merge(book);  // Update book entity
    em.getTransaction().commit();  // Commit the transaction
    
    return "Book returned successfully";
}


    @Override
    public List<BorrowRecord> findByStudent(Student student) {
        // Use JPQL to fetch the borrow records by student
        String jpql = "SELECT br FROM BorrowRecord br WHERE br.student = :student";
        Query query = em.createQuery(jpql);
        query.setParameter("student", student);
        
        // Execute the query and return the result
        return query.getResultList();
    }

   @Override
public List<BorrowRecord> getBorrowRecordsByStudent(Long studentId) {
    return em.createQuery(
        "SELECT br FROM BorrowRecord br WHERE br.student.id = :studentId", BorrowRecord.class)
        .setParameter("studentId", studentId)
        .getResultList();
}
@Override
public List<BorrowRecord> getUnreturnedRecordsByStudent(Long studentId) {
    return em.createQuery(
        "SELECT br FROM BorrowRecord br WHERE br.student.id = :studentId AND br.returned = FALSE", 
        BorrowRecord.class)
        .setParameter("studentId", studentId)
        .getResultList();
}

  

}
