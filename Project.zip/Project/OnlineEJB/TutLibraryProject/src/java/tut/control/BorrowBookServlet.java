package tut.control;

import ac.za.tut.bl.BookFacadeLocal;
import ac.za.tut.bl.BorrowRecordFacadeLocal;
import ac.za.tut.entities.Book;
import ac.za.tut.entities.BorrowRecord;
import ac.za.tut.entities.Student;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.Date;
import java.util.List;

@WebServlet(name = "BorrowBookServlet", urlPatterns = {"/BorrowBookServlet.do"})
public class BorrowBookServlet extends HttpServlet {

    @EJB
    private BookFacadeLocal bookFacade;

    @EJB
    private BorrowRecordFacadeLocal borrowRecordFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String bookIdStr = request.getParameter("bookId");

        HttpSession session = request.getSession(true);
        

        if (bookIdStr != null && session != null && session.getAttribute("student") != null) {
            Long bookId = Long.parseLong(bookIdStr);

            Book book = bookFacade.find(bookId);

            if (book != null && book.getQuantity() > 0) {
                // Reduce book quantity
                book.setQuantity(book.getQuantity() - 1);
                bookFacade.edit(book);

                // Create borrow record
                BorrowRecord record = new BorrowRecord();
                record.setBook(book);
   
                record.setBorrowDate(new Date());
                record.setReturned(false); // Initial status
                borrowRecordFacade.create(record);

                request.setAttribute("message", "Book borrowed successfully.");
            } else {
                request.setAttribute("error", "Book not available.");
            }
        } else {
            request.setAttribute("error", "Invalid request.");
        }

        request.getRequestDispatcher("student_dashboard.jsp").forward(request, response);
    }
}
