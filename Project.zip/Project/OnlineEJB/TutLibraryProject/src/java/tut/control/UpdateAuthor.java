package tut.control;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import ac.za.tut.bl.AuthorFacadeLocal;

import ac.za.tut.entities.Author;
import ac.za.tut.entities.Book;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author light
 */
public class UpdateAuthor extends HttpServlet {

  @EJB
    private AuthorFacadeLocal al;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
          try{
        Long id = Long.parseLong(request.getParameter("id"));
        String lastName = request.getParameter("lastName");
        String firstName = request.getParameter("firstName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String age = request.getParameter("age");
        String address = request.getParameter("address");
        Date creationDate = new Date();
        List<Book> books = new ArrayList<>();
        
        Author author = new Author(firstName,lastName,email,password,age,address, creationDate,books);
        al.find(id);
          if(author != null){
        al.edit(author);
        
        request.setAttribute("lastName",lastName );
        request.setAttribute("firstName",firstName );
        request.setAttribute("email",email );
        request.setAttribute("password",password );
        request.setAttribute("age",age);
        
        
        RequestDispatcher disp = request.getRequestDispatcher("update_student_outcome.jsp");
        disp.forward(request, response);
          }else {
           RequestDispatcher disp = request.getRequestDispatcher("error.jsp");
        disp.forward(request, response);
          }
       }catch(NumberFormatException ex){
         ex.printStackTrace();
         RequestDispatcher disp = request.getRequestDispatcher("error.jsp");
        disp.forward(request, response);
       }
    }

    
    

  
}
