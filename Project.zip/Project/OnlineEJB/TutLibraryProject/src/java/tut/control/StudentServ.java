package tut.control;

import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.Student;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "StudentServ", urlPatterns = {"/StudentServ.do"})
public class StudentServ extends HttpServlet {

    @EJB
    private StudentFacadeLocal st;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String name = request.getParameter("name");
        String idStr = request.getParameter("id");

        if (name == null || idStr == null || idStr.trim().isEmpty()) {
            request.setAttribute("error", "Missing login details.");
            request.getRequestDispatcher("login_student.jsp").forward(request, response);
            return;
        }

        try {
            Long id = Long.parseLong(idStr);
            Student student = st.findStudent(name, id);

            if (student != null) {
                HttpSession session = request.getSession(true);
                session.setAttribute("student", student);  // store in session
                request.getRequestDispatcher("student_dashboard.jsp").forward(request, response);
            } else {
                request.setAttribute("error", "Invalid student credentials.");
                request.getRequestDispatcher("login_student.jsp").forward(request, response);
            }
        } catch (NumberFormatException e) {
            request.setAttribute("error", "ID must be numeric.");
            request.getRequestDispatcher("login_student.jsp").forward(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("login_student.jsp");
    }
}
