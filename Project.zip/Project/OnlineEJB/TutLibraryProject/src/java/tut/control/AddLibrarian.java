package tut.control;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import ac.za.tut.bl.LibrarianFacadeLocal;
import ac.za.tut.entities.Librarian;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author light
 */
public class AddLibrarian extends HttpServlet {

   @EJB
   private LibrarianFacadeLocal ll;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
           String name = request.getParameter("firstName");
           String surname = request.getParameter("surname");
           String gender = request.getParameter("gender");
           String age = request.getParameter("age");
           Double salary = Double.parseDouble(request.getParameter("salary"));
           String  phoneNumber= request.getParameter("phoneNumber");
           String password = request.getParameter("password");
           String address = request.getParameter("address");
           String confirmPassword = request.getParameter("confirmPassword");
           Date creationDate = new Date();
           
           Librarian lb = new Librarian(name,surname,gender,age,salary,creationDate,address,phoneNumber,password,confirmPassword);
          
           ll.create(lb);
         
           
           request.setAttribute("lb", lb);
           
           RequestDispatcher disp = request.getRequestDispatcher("add_librarian_outcome.jsp");
           disp.forward(request, response);
    }

   
}
