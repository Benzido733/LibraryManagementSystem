/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package tut.control;

import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author light
 */
public class StudentProcess extends HttpServlet {

   @EJB
   private StudentFacadeLocal st;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String name =  request.getParameter("name");
        Long id = Long.parseLong(request.getParameter("id"));
        
           st.findStudent(name, id) ;  
              Student student = st.find(id);
              request.setAttribute("student",student);
             RequestDispatcher disp = request.getRequestDispatcher("student_dashboard.jsp");
             
             disp.forward(request, response);
         
     
         
         
    }

    
}
