package tut.control;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author light
 */
public class AddStudentServlet extends HttpServlet {

  @EJB
  private StudentFacadeLocal st;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
          String firstName = request.getParameter("firstName");
       String lastName = request.getParameter("lastName");
       String email = request.getParameter("email");
       String password = request.getParameter("password");
       String course = request.getParameter("course");
       
       Student student = new Student(firstName, lastName, email, password, course) ;
       st.create(student);
       request.setAttribute("firstName",firstName);
       request.setAttribute("lastName", lastName);
       request.setAttribute("email", email);
       request.setAttribute("password", password);
       request.setAttribute("course", course);
       request.setAttribute("student", student);
       
       
        RequestDispatcher disp = request.getRequestDispatcher("add_outcome.jsp");
        disp.forward(request,response);
       
       
        
        
          
    }

   
}
