package tut.control;


import ac.za.tut.bl.BorrowRecordFacadeLocal;
import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.BorrowRecord;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ReturnBookSession extends HttpServlet {

    @EJB
    private BorrowRecordFacadeLocal borrowRecordFacade;

    @EJB
    private StudentFacadeLocal studentFacade;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve student from session
        Student student = (Student) request.getSession().getAttribute("student");

        if (student != null) {
            // Get borrow records for the student
            List<BorrowRecord> borrowRecords = borrowRecordFacade.findByStudent(student);
            
            // Set the student and borrow records as request attributes
            request.setAttribute("student", student);
            request.setAttribute("borrowRecords", borrowRecords);
            
            // Forward to the return_book.jsp page
            request.getRequestDispatcher("return_book.jsp").forward(request, response);
        } else {
            // If no student is found, redirect to login page
            response.sendRedirect("login_student.jsp");
        }
    }
}
