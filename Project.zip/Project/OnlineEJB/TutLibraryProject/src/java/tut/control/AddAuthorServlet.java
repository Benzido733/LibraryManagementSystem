package tut.control;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import ac.za.tut.bl.AuthorFacadeLocal;
import ac.za.tut.entities.Author;
import ac.za.tut.entities.Book;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author light
 */
public class AddAuthorServlet extends HttpServlet {
  @EJB
  private AuthorFacadeLocal al;
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
              String firstName = request.getParameter("firstName");
       String lastName = request.getParameter("lastName");
       String email = request.getParameter("email");
       String password = request.getParameter("password");
       String age = request.getParameter("age");
       String address = request.getParameter("address");
       Date creationDate = new Date();
       
       
      
       Integer quantity1 = Integer.parseInt(request.getParameter("firstBookQuan"));
        String title1 = request.getParameter("firstBook");
       Integer quantity2 =Integer.parseInt( request.getParameter("secondBookQuan"));
        String title2 = request.getParameter("secondBook");
       Integer quantity3=Integer.parseInt(request.getParameter("thirdBookQuan"));
        String title3 = request.getParameter("thirdBook");
       List<Book> books = new ArrayList<>();
          Book book1 = new Book();
          book1.setTitle(title1);
          book1.setQuantity(quantity1);
          Book book2 = new Book();
          book2.setQuantity(quantity2);
          book2.setTitle(title2);
          Book book3 = new Book();
          book3.setTitle(title3);
          book3.setQuantity(quantity3);
          books.add(book1);
          books.add(book2);
          books.add(book3);
       Author author = new Author(firstName , lastName , email , password , age, address,creationDate,books) ;
       al.create(author);
       request.setAttribute("firstName",firstName);
       request.setAttribute("lastName", lastName);
       request.setAttribute("email", email);
       request.setAttribute("password", password);
       request.setAttribute("age", age);
       request.setAttribute("address", address);
       request.setAttribute("author", author);
       request.setAttribute("books", books);
       
       
      
    
        RequestDispatcher disp = request.getRequestDispatcher("add_author_outcome.jsp");
        disp.forward(request,response);
       
        
    }

  

}
