/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package tut.control;

import ac.za.tut.bl.LibrarianFacadeLocal;
import ac.za.tut.entities.Librarian;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author light
 */
public class StartLibrarianSession extends HttpServlet {

   
@EJB 
private LibrarianFacadeLocal ll;
   
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
               
        String name =  request.getParameter("name");
        Long id = Long.parseLong(request.getParameter("id"));
        
         if(ll.findLibrarian(name, id) != null){
              Librarian lib = ll.find(id);
              request.setAttribute("librarian",lib);
             RequestDispatcher disp = request.getRequestDispatcher("index.html");
             
             disp.forward(request, response);
         
         }else{
           RequestDispatcher disp = request.getRequestDispatcher("login_error.jsp");
             
             disp.forward(request, response);
         }
    }

   

}
