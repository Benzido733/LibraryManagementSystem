/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package tut.control;

import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author light
 */
public class DeleteStudentServlet extends HttpServlet {

   @EJB
   private StudentFacadeLocal sf;
    @Override

protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    try {
        Long id = Long.parseLong(request.getParameter("id"));
        Student st = sf.find(id);

        if (st != null) {
            sf.remove(st);
            request.setAttribute("message", "Student deleted successfully.");
        } else {
            request.setAttribute("error", "Student with ID " + id + " not found.");
        }

    } catch (NumberFormatException e) {
        request.setAttribute("error", "Invalid student ID format.");
    } catch (Exception e) {
        request.setAttribute("error", "An unexpected error occurred: " + e.getMessage());
    }

    RequestDispatcher disp = request.getRequestDispatcher("delete_student_outcome.jsp");
    disp.forward(request, response);
}

  
}
