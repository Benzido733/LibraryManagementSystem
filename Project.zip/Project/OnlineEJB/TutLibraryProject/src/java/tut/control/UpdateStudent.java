package tut.control;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author light
 */
public class UpdateStudent extends HttpServlet {

    @EJB
    private StudentFacadeLocal st;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
        
       try{
        Long id = Long.parseLong(request.getParameter("id"));
        String lastName = request.getParameter("lastName");
        String firstName = request.getParameter("firstName");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        
        Student student = createStudent(id,firstName,lastName,email,password);
        st.edit(student);
        request.setAttribute( "id", id);
        request.setAttribute("lastName",lastName );
        request.setAttribute("firstName",firstName );
        request.setAttribute("email",email );
        request.setAttribute("password",password );
        
        
        RequestDispatcher disp = request.getRequestDispatcher("update_student_outcome.jsp");
        disp.forward(request, response);
       }catch(NumberFormatException ex){
         ex.printStackTrace();
         RequestDispatcher disp = request.getRequestDispatcher("error.jsp");
        disp.forward(request, response);
       }
    }

    private Student createStudent(Long id , String firstName , String lastName , String email , String password ) {
       Student s = st.find(id);
       s.setFirstName(firstName);
       s.setEmail(email);
       s.setLastName(lastName);
       s.setPassword(password);
       return s;
    
    }

   
}
