/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package tut.control;

import ac.za.tut.bl.LibrarianFacadeLocal;
import ac.za.tut.entities.Librarian;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author light
 */
public class SearchLibrarian extends HttpServlet {

   @EJB
   private LibrarianFacadeLocal ll;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      
             Long id = Long.parseLong(request.getParameter("id"));
             
              Librarian lib = ll.find(id);
              
              request.setAttribute("lib", lib);
              
              RequestDispatcher disp = request.getRequestDispatcher("search_librarian_outcome.jsp");
              
              disp.forward(request, response);
    }

  

}
