package tut.control;

import ac.za.tut.bl.BookFacadeLocal;
import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.Book;
import ac.za.tut.entities.BorrowRecord;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BorrowBookSession extends HttpServlet {

    @EJB
    private BookFacadeLocal bookFacade;
    @EJB
    private StudentFacadeLocal studentFacade;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Fetch books and display them to the user for borrowing
        List<Book> books = bookFacade.findAll();
        request.getSession().setAttribute("books", books);
        request.getRequestDispatcher("borrow.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Check if the student is logged in
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("studentId") == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        String studentId = (String) session.getAttribute("studentId");
        String bookIdStr = request.getParameter("bookId");

        // Fetch student and book based on IDs
        Student student = studentFacade.find(studentId);
        Book book = bookFacade.find(Long.parseLong(bookIdStr));

        if (student != null && book != null && !book.isBorrowed()) {
            // Proceed with borrowing the book
            BorrowRecord record = new BorrowRecord(student, book, new Date(), null, false);
            student.getBorrowRecords().add(record);
            book.setBorrowed(true);

            studentFacade.edit(student);
            bookFacade.edit(book);

            request.setAttribute("message", "Book borrowed successfully!");
        } else {
            request.setAttribute("error", "Book is already borrowed or invalid data.");
        }

        request.getRequestDispatcher("borrow_result.jsp").forward(request, response);
    }
}
