/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package tut.control;

import ac.za.tut.bl.StudentFacadeLocal;
import ac.za.tut.entities.Student;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author light
 */
@WebServlet(name = "StartStudentSession", urlPatterns = {"/StartStudentSession.do"})

public class StartStudentSession extends HttpServlet {
  @EJB
  private StudentFacadeLocal st;
  
    @Override

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String name =  request.getParameter("name");
        Long id = Long.parseLong(request.getParameter("id"));
        
         if(st.findStudent(name, id) != null){
              Student student = st.find(id);
              request.setAttribute("student",student);
             RequestDispatcher disp = request.getRequestDispatcher("student_dashboard.jsp");
             
             disp.forward(request, response);
         
         }else{
           RequestDispatcher disp = request.getRequestDispatcher("login_error.jsp");
             
             disp.forward(request, response);
         }
         
         
         
         
         
    }

   
}
